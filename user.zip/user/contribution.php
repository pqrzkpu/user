<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>EASTPAC | Contribution</title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <!-- Bootstrap 3.3.7 -->
  <link rel="stylesheet" href="jquery.dataTables.min.css">
  <link rel="stylesheet" href="bower_components/bootstrap/dist/css/bootstrap.min.css">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="bower_components/font-awesome/css/font-awesome.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="bower_components/Ionicons/css/ionicons.min.css">
  <!--DataTables-->
  <link rel="stylesheet" href="bower_components/datatables.net-bs/css/dataTables.bootstrap.min.css">
  <!-- jvectormap -->
  <link rel="stylesheet" href="bower_components/jvectormap/jquery-jvectormap.css">
    
  <!-- Theme style -->
  <!-- Theme style -->
  <link rel="stylesheet" href="dist/css/AdminLTE.css">
  <link rel="stylesheet" href="dist/css/contribution.css">
  <link rel="stylesheet" href="dist/css/skins/skin-black.css">


  <!-- Google Font -->
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic">
</head>
    



<body class="hold-transition skin-black fixed">
<div class="wrapper">

<?php include('page-header.html') ?>
  <!-- Left side column. contains the logo and sidebar -->

<?php include('page-sidebar.html') ?>
  <!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <section class="content">
      <div class="row">
        <div class="col-sm-12" style="margin-top: 10px">
            <div class="box box-warning">
                <div class="box-header with-border">
                  <h2 class="box-title">Buy Tokens</h2>
                    <div class="box-body">
                       <div class="row">
                            <div class="user-panel">
                            <form action="#">
                                <h5 class="user-panel-subtitle">01. Select the payment method and calculate token price</h5>
                                <div class="gaps-1x"></div>
                                <div class="payment-list">
                                    <div class="row">
                                       <div class="col-md-3 col-sm-6">
                                            <div class="payment-item">
                                                <input class="payment-check" type="radio" id="payeth" name="payOption" value="tranxETH" checked="">
                                                <label for="payeth">
                                                    <div class="payment-icon payment-icon-eth"><img src="dist/img/icon-ethereum.png" alt="icon"></div>
                                                    <span class="payment-cur">Ethereum</span>
                                                </label>
                                                <span>@ 0.1 ETH</span>
                                            </div>       
                                       </div><!-- .col -->
                                       <div class="col-md-3 col-sm-6">
                                            <div class="payment-item">
                                                <input class="payment-check" type="radio" id="paylightcoin" name="payOption" value="tranxLTC">
                                                <label for="paylightcoin">
                                                    <div class="payment-icon payment-icon-ltc"><img class="payment-icon" src="dist/img/icon-lightcoin.png" alt="icon"></div>
                                                    <span class="payment-cur">Litecoin</span>
                                                </label>
                                                <span>@ 0.1 LTC</span>
                                            </div>
                                       </div><!-- .col -->
                                       <div class="col-md-3 col-sm-6">
                                           <div class="payment-item">
                                                <input class="payment-check" type="radio" id="paybtc" name="payOption" value="tranxBTC">
                                                <label for="paybtc">
                                                    <div class="payment-icon payment-icon-btc"><img class="payment-icon" src="dist/img/icon-bitcoin.png" alt="icon"></div>
                                                    <span class="payment-cur">Bitcoin</span>
                                                </label>
                                                <span>@ 0.05 BTC</span>
                                            </div>
                                       </div><!-- .col -->
                                       <div class="col-md-3 col-sm-6">
                                           <div class="payment-item">
                                                <input class="payment-check" type="radio" id="payusd" name="payOption" value="tranxUSD">
                                                <label for="payusd">
                                                    <div class="payment-icon payment-icon-usd"><img class="payment-icon" src="dist/img/icon-creditcard.png" alt="icon"></div>
                                                    <span class="payment-cur">US Dollar</span>
                                                </label>
                                                <span>@ 0.5 USD</span>
                                            </div>
                                       </div><!-- .col -->
                                    </div><!-- .row -->
                                </div><!-- .payment-list -->
                                <div class="gaps-1x"></div>
                                <h5 class="user-panel-subtitle">02. Set amount of ICOX tokens you would like to purchase</h5>
                                <p>To become a part of the ICO Crypto project and purchase of ICOX token will only be possible after payment made and receving an approval.  As you like to participate our project, please select payment method and enter the amount of ICOX tokens you wish to purchase. You can buy ICOX tokens using ETH, BTC, LTC or USD. </p>
                                <div class="gaps-1x"></div>
                                <div class="row">
                                    <div class="col-md-8">
                                        <div class="payment-calculator">
                                            <div class="payment-get">
                                                <label for="paymentGet">Tokens to Purchase</label>
                                                <div class="payment-input">
                                                    <input class="input-bordered" type="text" id="paymentGet" value="1200">
                                                    <span class="payment-get-cur payment-cal-cur">icox</span>    
                                                </div>
                                            </div>
                                            <em class="ti ti-exchange-vertical"></em>
                                            <div class="payment-from">
                                                <label for="paymentFrom">Payment Amount</label>
                                                <div class="payment-input">
                                                    <input class="input-bordered" type="text" id="paymentFrom" value="600">
                                                    <span class="payment-from-cur payment-cal-cur">usd</span>    
                                                </div>
                                            </div>
                                        </div>
                                        <div class="gaps-2x d-md-none"></div>
                                    </div><!-- .col -->
                                    <div class="col-md-4">
                                        <div class="payment-bonus">
                                            <h6 class="payment-bonus-title">Current Bonus</h6>
                                            <span class="payment-bonus-amount">20% <span>on pre-sales</span></span>
                                            <span class="payment-bonus-time">End at - 09 Jul, 2018</span>
                                        </div>
                                        <div class="gaps-1x d-md-none"></div>
                                    </div><!-- .col -->
                                </div><!-- .row -->
                                <div class="gaps-1x"></div>
                                <div class="payment-calculator-note"><i class="fa fa-info-circle"></i>The calculator helps you to convert required currency to ICOX tokens.</div>
                                <div class="gaps-3x"></div>
                                <div class="payment-summary">
                                    <div class="row">
                                        <div class="col-md-4">
                                            <div class="payment-summary-item payment-summary-final">
                                                <h6 class="payment-summary-title">Final Payment</h6>
                                                <div class="payment-summary-info">
                                                    <span class="payment-summary-amount">600.00</span> <span>usd</span>
                                                </div>
                                            </div>
                                        </div><!-- .col -->
                                        <div class="col-md-4">
                                            <div class="payment-summary-item payment-summary-bonus">
                                                <h6 class="payment-summary-title">Received Bonus</h6>
                                                <div class="payment-summary-info">
                                                    <span>+</span> <span class="payment-summary-amount">600.00</span> <span>icox</span>
                                                </div>
                                            </div>
                                        </div><!-- .col -->
                                        <div class="col-md-4">
                                            <div class="payment-summary-item payment-summary-tokens">
                                                <h6 class="payment-summary-title">Tokens Received</h6>
                                                <div class="payment-summary-info">
                                                    <span class="payment-summary-amount">12,200</span> <span>icox</span>
                                                </div>
                                            </div>
                                        </div><!-- .col -->
                                    </div><!-- .row -->
                                </div><!-- .payment-summary -->
                                <a href="#" class="btn btn-primary payment-btn" data-toggle="modal" data-target="#tranxETH">Purchase Tokens</a>
                            </form><!-- form -->
                        </div>
                       </div>
                
                </div>
              </div>
                
           
          </div>
        </div>
      </div>
      
</section>

</div>
</div>
<!--Footer section-->
<?php include('page-footer.html'); ?>

<!-- jQuery 3 -->
<script src="bower_components/jquery/dist/jquery.min.js"></script>
<!-- Bootstrap 3.3.7 -->
<script src="bower_components/bootstrap/dist/js/bootstrap.min.js"></script>
<!-- FastClick -->
<script src="bower_components/fastclick/lib/fastclick.js"></script>
<!-- AdminLTE App -->
<script src="dist/js/adminlte.min.js"></script>
<!-- Sparkline -->
<script src="bower_components/jquery-sparkline/dist/jquery.sparkline.min.js"></script>
<!-- jvectormap  -->
<script src="plugins/jvectormap/jquery-jvectormap-1.2.2.min.js"></script>
<script src="plugins/jvectormap/jquery-jvectormap-world-mill-en.js"></script>
<!-- SlimScroll -->
<script src="bower_components/jquery-slimscroll/jquery.slimscroll.min.js"></script>
<!-- ChartJS -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.13.0/moment.min.js"></script>
<script src="bower_components/chart.js/Chart.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.1.4/Chart.bundle.min.js"></script>
<!-- AdminLTE dashboard demo (This is only for demo purposes) -->
<!-- <script src="dist/js/pages/dashboard2.js"></script> -->
<!-- AdminLTE for demo purposes -->
<script src="dist/js/demo.js"></script>
<script src="bower_components/datatables.net/js/jquery.dataTables.min.js"></script>
<script src="bower_components/datatables.net-bs/js/dataTables.bootstrap.min.js"></script>

<script src="bower_components/Flot/jquery.flot.js"></script>
<!-- FLOT RESIZE PLUGIN - allows the chart to redraw when the window is resized -->
<script src="bower_components/Flot/jquery.flot.resize.js"></script>
<!-- FLOT PIE PLUGIN - also used to draw donut charts -->
<script src="bower_components/Flot/jquery.flot.pie.js"></script>
<!-- FLOT CATEGORIES PLUGIN - Used to draw bar charts -->
<script src="bower_components/Flot/jquery.flot.categories.js"></script>
<script src="bower_components/chart.js/amcharts.js"></script>
<script src="bower_components/chart.js/serial.js"></script>


</body>
</html>