<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>EASTPAC | Transaction</title>
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <!-- Bootstrap 3.3.7 -->
  <link rel="stylesheet" href="jquery.dataTables.min.css">
  <link rel="stylesheet" href="bower_components/bootstrap/dist/css/bootstrap.min.css">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="bower_components/font-awesome/css/font-awesome.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="bower_components/Ionicons/css/ionicons.min.css">
  <!--DataTables-->
  <link rel="stylesheet" href="bower_components/datatables.net-bs/css/dataTables.bootstrap.min.css">
  <!-- jvectormap -->
  <link rel="stylesheet" href="bower_components/jvectormap/jquery-jvectormap.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="dist/css/AdminLTE.css">
  <link rel="stylesheet" href="dist/css/skins/skin-black.css">
  <!-- Google Font -->
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic">
</head>
<style> 
.user-bg .user-icon{
    position: absolute;   
}
    
.user-bg{
    width: 75%;
    position: absolute;
    z-index: 0; 
    margin-left: 15%;
}
.user-icon{
  position: absolute;
	width: 80%;
	margin-top: 20%;
	left: 45%;
	z-index: 10;  
}
</style>
<body class="hold-transition skin-black fixed">
<div class="wrapper">

  <?php include('page-header.html');?>
  <!-- Left side column. contains the logo and sidebar -->
  <?php include('page-sidebar.html');?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Main content -->
    <section class="content container-fluid" style="margin-top: 20px; margin-left:20px; margin-right:20px;">
      <form class="form-horizontal" id="frm_transfer_eth" action="starter.html" method="post">
        <div class="row">
            <div class="box box-warning">
               
                <div class="box-body">
                    <div class="row">
                        <div class="col-sm-3">
                            <img src="dist/img/bio-bg.png" class="user-bg">
                            <img src="dist/img/user-big.png" class="user-icon">
                        </div>
                        <div class="col-sm-2"></div>
                        <div class="col-sm-6">
                             <div class="box-header">
                              <h3 class="box-title">Account Information</h3>
                            </div>

                            <div class="form-group">
                              <label for="inputEmail3" class="col-sm-3 ">Full Name</label>
                              <div class="col-sm-9">
                                 <input type="text" class="form-control" id="name" placeholder="" name="name">
                              </div>
                            </div>
                            <div class="form-group">
                              <label for="inputPassword3" class="col-sm-3">Username</label>       
                              <div class="col-sm-9">
                                  <input type="text" class="form-control" id="username" placeholder="" name="username">
                              </div>
                            </div>
                            <div class="form-group">
                              <label for="inputPassword3" class="col-sm-3">Mobile Phone</label>       
                              <div class="col-sm-9">
                                  <input type="text" class="form-control" id="phone" placeholder="" name="phone">
                              </div>
                            </div>
                             <div class="form-group">
                                <label for="inputPassword3" class="col-sm-3">Email</label>       
                                <div class="col-sm-9">
                                  <input type="text" class="form-control" id="email" placeholder="" name="email">
                                </div>
                             </div>
                             <div class="form-group">
                                <label for="inputPassword3" class="col-sm-3">Old Password</label>       
                                <div class="col-sm-9">
                                    <input type="text" class="form-control" id="password" placeholder="" name="password">
                                </div>
                             </div>
                             <div class="form-group">
                                <label for="inputPassword3" class="col-sm-3">New Password</label>       
                                <div class="col-sm-9">
                                    <input type="text" class="form-control" id="password" placeholder="" name="password">
                                </div>
                             </div>
                             <div class="form-group">
                                <label for="inputPassword3" class="col-sm-3">Confirm New Password</label>       
                                <div class="col-sm-9">
                                    <input type="text" class="form-control" id="password" placeholder="" name="password">
                                </div>
                             </div>
                             <div class="row pull-right">
                                <div class="col-sm-6">
                                   <button type="submit" class="btn btn-warning pull-right" onclick="return false;">Cancel</button>
                                </div>
                                <div class="col-sm-6">
                                   <button type="submit" id="btnSubmit" class="btn btn-info pull-right" onclick="return false;">Update</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
         </div>
      </form>
    </section>
  </div>
  <!-- /.content-wrapper -->

<!--Footer section-->
  <?php include('page-footer.html');?>

</div>
<!-- ./wrapper -->

<!-- jQuery 3 -->
<script src="bower_components/jquery/dist/jquery.min.js"></script>
<!-- Bootstrap 3.3.7 -->
<script src="bower_components/bootstrap/dist/js/bootstrap.min.js"></script>
<!-- FastClick -->
<script src="bower_components/fastclick/lib/fastclick.js"></script>
<!-- AdminLTE App -->
<script src="dist/js/adminlte.min.js"></script>

<!-- SlimScroll -->
<script src="bower_components/jquery-slimscroll/jquery.slimscroll.min.js"></script>
<!-- ChartJS -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.13.0/moment.min.js"></script>
<script src="bower_components/chart.js/Chart.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.1.4/Chart.bundle.min.js"></script>
<!-- AdminLTE dashboard demo (This is only for demo purposes) -->
<!-- <script src="dist/js/pages/dashboard2.js"></script> -->
<!-- AdminLTE for demo purposes -->
<script src="dist/js/demo.js"></script>
<script src="bower_components/datatables.net/js/jquery.dataTables.min.js"></script>
<script src="bower_components/datatables.net-bs/js/dataTables.bootstrap.min.js"></script>



</body>
</html>